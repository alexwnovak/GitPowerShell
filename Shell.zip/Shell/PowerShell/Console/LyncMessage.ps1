Import-Module "C:\Program Files\Microsoft Office\Office15\LyncSDK\Assemblies\Desktop\Microsoft.Lync.Model.dll"

$lyncClient = [Microsoft.Lync.Model.LyncClient]::GetClient()

function TabExpansion($line, $lastWord)
{
   $command = $line.ToLower().Split( " " )[0].Trim()

   if ( $command -eq "im" )
   {
      $ar = $lyncClient.ContactManager.BeginLookup( "alex", $myCallback, $null );
      
      $ret = $lyncClient.ContactManager.EndLookup( $ar ) -as [Microsoft.Lync.Model.Contact]
      
      Write-Host $ret.Uri
      
      return @("One", "Two")
   }
}
