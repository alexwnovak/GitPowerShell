#==================================================================================================
# GitHub Profile
#==================================================================================================

Push-Location (Split-Path -Path $MyInvocation.MyCommand.Definition -Parent)

Import-Module \Git\posh-git\posh-git

$global:isOdd = $false

function global:prompt
{
    $realLASTEXITCODE = $LASTEXITCODE

    # Reset color, which can be messed up by Enable-GitColors
    $Host.UI.RawUI.ForegroundColor = $GitPromptSettings.DefaultForegroundColor

    Write-Host "[" -ForegroundColor DarkGray -NoNewLine
    Write-Host( $pwd.ProviderPath ) -ForegroundColor Blue -nonewline
    Write-Host "]" -ForegroundColor DarkGray -NoNewLine

    Write-VcsStatus

    $global:LASTEXITCODE = $realLASTEXITCODE
    
    Write-Host
    
    if ( $global:isOdd )
    {
        $global:isOdd = $false
        Write-Host "(|)  (" -ForegroundColor DarkYellow -NoNewLine
        Write-Host "^" -ForegroundColor Cyan -NoNewLine
        Write-Host ",," -ForegroundColor DarkYellow -NoNewLine
        Write-Host "^" -ForegroundColor Cyan -NoNewLine
        Write-Host ") (\/)" -ForegroundColor DarkYellow -NoNewLine
    }
    else
    {
        $global:isOdd = $true
        Write-Host "(\/) (" -ForegroundColor DarkYellow -NoNewLine
        Write-Host "^" -ForegroundColor Cyan -NoNewLine
        Write-Host ",," -ForegroundColor DarkYellow -NoNewLine
        Write-Host "^" -ForegroundColor Cyan -NoNewLine
        Write-Host ") (|)" -ForegroundColor DarkYellow -NoNewLine
    }
    
    Write-Host " $" -ForegroundColor DarkGray -NoNewLine
    return " "
}

Enable-GitColors

Pop-Location

Start-SshAgent -Quiet

#==================================================================================================
# [Eof]
#==================================================================================================
